Чекушки об мост

index.html - обычная игра (телефон). Картинки лежат в папке images.
vr.html    - VR-версия для очков (Meta Quest Browser и др.): кнопка «ВОЙТИ В VR».
images/    - картинки: bridge.jpg, bridge_train.jpg, reeds.jpg, skin_*.png (марки чекушек), icon.png.
             Чтобы заменить картинку, положи свою с тем же именем (фоны 9:16, лучше 810x1440).

chekushki-odin-fayl.html     - обычная игра одним файлом, картинки внутри.
chekushki-vr-odin-fayl.html  - VR-версия одним файлом, картинки внутри.

Как выложить (GitHub Pages): загрузи в репозиторий index.html + vr.html + папку images
(или два одиночных файла, переименовав их в index.html и vr.html), включи Settings -> Pages.
VR открывается по ссылке  https://ТВОЙ_НИК.github.io/ИМЯ_РЕПО/vr.html  в браузере очков.
Прогресс (бабки, марки бутылок) общий у обычной игры и VR, если они открыты с одного адреса.

Android APK: загружай zip в конвертер (главный файл index.html).
iPhone: Safari -> Поделиться -> На экран «Домой».
